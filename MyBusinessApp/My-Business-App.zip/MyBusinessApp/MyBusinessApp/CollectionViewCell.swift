//
//  CollectionViewCell.swift
//  MyBusinessApp
//
//  Created by Aaron on 14/04/2015.
//  Copyright (c) 2015 GeekyLemonDevelopment. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var ImageView: UIImageView!
    
    
}
